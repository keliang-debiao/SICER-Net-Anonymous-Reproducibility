import pandas as pd
from sicer_net.data import add_grouped_folds


def test_duplicate_components_do_not_cross_folds():
    rows = []
    for group in range(100):
        for member in range(2):
            rows.append({
                "label": group % 2,
                "style": group % 10,
                "source": ["human", "ldm", "sd21"][group % 3],
                "duplicate_group": f"g{group:03d}",
            })
    frame = add_grouped_folds(pd.DataFrame(rows), 5, 17)
    assert frame.groupby("duplicate_group").fold.nunique().max() == 1
    assert sorted(frame.fold.unique()) == [0, 1, 2, 3, 4]
