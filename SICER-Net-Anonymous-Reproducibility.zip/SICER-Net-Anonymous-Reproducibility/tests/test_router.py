import torch
from sicer_net.model import ReliabilityRouter


def test_router_normalization():
    router = ReliabilityRouter()
    representations = {name: torch.randn(4, 512) for name in ("rgb", "hf", "ci")}
    reliability = torch.rand(4, 3).clamp_min(0.01)
    fused, weights = router(representations, reliability)
    assert fused.shape == (4, 512)
    assert weights.shape == (4, 3)
    assert torch.allclose(weights.sum(1), torch.ones(4), atol=1e-6)
