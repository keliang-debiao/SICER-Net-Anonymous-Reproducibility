import torch
from sicer_net.calibration import StyleBalancedReliabilityCalibrator


def test_sbrc_temperature_bounds():
    calibrator = StyleBalancedReliabilityCalibrator(0.7, 2.5, 16)
    logits = torch.randn(12)
    reliability = torch.rand(12, 3)
    cue_logits = torch.randn(12, 3)
    temperature = calibrator.temperature(logits, reliability, cue_logits)
    assert torch.all(temperature >= 0.7)
    assert torch.all(temperature <= 2.5)
