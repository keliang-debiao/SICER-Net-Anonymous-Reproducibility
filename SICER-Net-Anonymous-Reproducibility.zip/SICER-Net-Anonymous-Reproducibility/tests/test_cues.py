import torch
from sicer_net.cues import CueConstructor


def test_cue_shapes_and_ranges():
    constructor = CueConstructor()
    image = torch.rand(2, 3, 224, 224)
    output = constructor(image)
    assert set(output) == {"rgb", "hf", "ci"}
    for value in output.values():
        assert value.shape == (2, 3, 224, 224)
        assert torch.isfinite(value).all()
        assert value.min() >= 0 and value.max() <= 1
