import numpy as np
from sicer_net.metrics import expected_calibration_error, select_threshold


def test_metric_contracts():
    labels = np.array([0, 0, 1, 1])
    probabilities = np.array([0.1, 0.2, 0.8, 0.9])
    assert expected_calibration_error(labels, probabilities, bins=2) >= 0
    threshold = select_threshold(labels, probabilities, step=0.01)
    assert 0 <= threshold <= 1
