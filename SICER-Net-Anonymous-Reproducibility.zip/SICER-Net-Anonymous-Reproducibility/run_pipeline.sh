#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="${1:-configs/main.yaml}"

python scripts/audit_data.py --config "$CONFIG_PATH" --dataset development
python scripts/audit_data.py --config "$CONFIG_PATH" --dataset external
python scripts/check_cross_corpus.py --config "$CONFIG_PATH"
python scripts/build_splits.py --config "$CONFIG_PATH"
python scripts/train_cv.py --config "$CONFIG_PATH"
python scripts/fit_calibrators.py --config "$CONFIG_PATH"
python scripts/train_final.py --config "$CONFIG_PATH"
python scripts/evaluate_external.py --config "$CONFIG_PATH"
python scripts/run_ablations.py --config "$CONFIG_PATH" --matrix configs/ablations.yaml --execute
python scripts/run_robustness.py --config "$CONFIG_PATH"
python scripts/run_statistics.py --config "$CONFIG_PATH"
python scripts/export_tables.py --config "$CONFIG_PATH"
