from __future__ import annotations

import torch
from torch import nn
import timm


class ImageBaseline(nn.Module):
    def __init__(self, name: str, pretrained: bool = True):
        super().__init__()
        self.model = timm.create_model(name, pretrained=pretrained, num_classes=1)

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        return self.model(image).squeeze(1)


class MultiCueAggregationBaseline(nn.Module):
    def __init__(self, feature_dim: int = 256):
        super().__init__()
        self.encoders = nn.ModuleList([
            timm.create_model("resnet18", pretrained=True, num_classes=feature_dim) for _ in range(3)
        ])
        self.attention = nn.Sequential(nn.Linear(feature_dim * 3, 128), nn.GELU(), nn.Linear(128, 3))
        self.head = nn.Linear(feature_dim, 1)

    def forward(self, cues: list[torch.Tensor]) -> torch.Tensor:
        features = [encoder(cue) for encoder, cue in zip(self.encoders, cues)]
        weights = torch.softmax(self.attention(torch.cat(features, dim=1)), dim=1)
        fused = sum(weights[:, i:i+1] * features[i] for i in range(3))
        return self.head(fused).squeeze(1)


class SpatialFrequencyBaseline(nn.Module):
    def __init__(self):
        super().__init__()
        self.spatial = timm.create_model("convnext_tiny", pretrained=True, num_classes=256)
        self.frequency = timm.create_model("resnet18", pretrained=True, num_classes=256)
        self.head = nn.Sequential(nn.Linear(512, 128), nn.GELU(), nn.Linear(128, 1))

    def forward(self, rgb: torch.Tensor, high_frequency: torch.Tensor) -> torch.Tensor:
        fused = torch.cat([self.spatial(rgb), self.frequency(high_frequency)], dim=1)
        return self.head(fused).squeeze(1)


BASELINE_REGISTRY = {
    "resnet50": lambda: ImageBaseline("resnet50"),
    "convnext_tiny": lambda: ImageBaseline("convnext_tiny"),
    "vit_small_patch16_224": lambda: ImageBaseline("vit_small_patch16_224"),
    "scadet": SpatialFrequencyBaseline,
    "mcan": MultiCueAggregationBaseline,
}
