from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


def mean_pairwise_js(cue_logits: torch.Tensor) -> torch.Tensor:
    p = torch.sigmoid(cue_logits).clamp(1e-6, 1 - 1e-6)
    distributions = torch.stack([p, 1 - p], dim=-1)
    terms = []
    for a, b in ((0, 1), (0, 2), (1, 2)):
        x, y = distributions[:, a], distributions[:, b]
        m = 0.5 * (x + y)
        js = 0.5 * ((x * (x.log() - m.log())).sum(-1) + (y * (y.log() - m.log())).sum(-1))
        terms.append(js)
    return torch.stack(terms, dim=1).mean(dim=1)


class GlobalTemperature(nn.Module):
    def __init__(self):
        super().__init__()
        self.log_temperature = nn.Parameter(torch.zeros(()))

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return logits / self.log_temperature.exp().clamp_min(1e-4)

    def fit(self, logits: torch.Tensor, labels: torch.Tensor, iterations: int = 100) -> "GlobalTemperature":
        optimizer = torch.optim.LBFGS([self.log_temperature], max_iter=iterations, line_search_fn="strong_wolfe")
        def closure():
            optimizer.zero_grad()
            loss = F.binary_cross_entropy_with_logits(self(logits), labels.float())
            loss.backward()
            return loss
        optimizer.step(closure)
        return self


class StyleBalancedReliabilityCalibrator(nn.Module):
    def __init__(self, minimum_temperature: float = 0.7, maximum_temperature: float = 2.5, hidden_units: int = 16):
        super().__init__()
        self.minimum_temperature = minimum_temperature
        self.maximum_temperature = maximum_temperature
        self.network = nn.Sequential(nn.Linear(5, hidden_units), nn.GELU(), nn.Linear(hidden_units, 1))

    def features(self, logits: torch.Tensor, reliability: torch.Tensor, cue_logits: torch.Tensor) -> torch.Tensor:
        disagreement = mean_pairwise_js(cue_logits).unsqueeze(1)
        magnitude = logits.abs().unsqueeze(1)
        return torch.cat([reliability, disagreement, magnitude], dim=1)

    def temperature(self, logits: torch.Tensor, reliability: torch.Tensor, cue_logits: torch.Tensor) -> torch.Tensor:
        raw = self.network(self.features(logits, reliability, cue_logits)).squeeze(1)
        span = self.maximum_temperature - self.minimum_temperature
        return self.minimum_temperature + span * torch.sigmoid(raw)

    def forward(self, logits: torch.Tensor, reliability: torch.Tensor, cue_logits: torch.Tensor) -> torch.Tensor:
        return logits / self.temperature(logits, reliability, cue_logits)

    def fit(self, logits, reliability, cue_logits, labels, learning_rate: float = 0.01, steps: int = 500):
        optimizer = torch.optim.Adam(self.parameters(), lr=learning_rate)
        best = None
        for _ in range(steps):
            optimizer.zero_grad()
            calibrated = self(logits, reliability, cue_logits)
            loss = F.binary_cross_entropy_with_logits(calibrated, labels.float())
            loss.backward()
            optimizer.step()
            value = float(loss.detach())
            if best is None or value < best[0]:
                best = (value, {k: v.detach().clone() for k, v in self.state_dict().items()})
        self.load_state_dict(best[1])
        return self
