"""SICER-Net implementation."""

__version__ = "1.0.0"
