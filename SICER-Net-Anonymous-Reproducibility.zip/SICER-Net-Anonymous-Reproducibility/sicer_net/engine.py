from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
from sklearn.metrics import roc_auc_score
from torch.cuda.amp import GradScaler, autocast
from torch.nn import functional as F

from .losses import GroupDRO, combined_loss


def set_seed(seed: int) -> None:
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def gradient_reverse_coefficient(epoch: int, warmup_epochs: int, maximum: float) -> float:
    return maximum * min(1.0, max(0.0, epoch / max(1, warmup_epochs)))


def train_epoch(model, loader, optimizer, scaler, group_dro, cfg, device, epoch):
    model.train()
    aggregate = {}
    coefficient = gradient_reverse_coefficient(epoch, cfg["training"]["warmup_epochs"], cfg["training"]["gradient_reverse_maximum"])
    if not cfg.get("ablation", {}).get("style_adversary", True):
        coefficient = 0.0
    for batch in loader:
        image = batch["image"].to(device)
        labels = batch["label"].to(device)
        styles = batch["style"].to(device)
        groups = batch["group_index"].to(device)
        optimizer.zero_grad(set_to_none=True)
        with autocast(enabled=cfg["training"]["mixed_precision"]):
            output_a = model(image, coefficient)
            second_image = batch.get("image_b", torch.flip(image, dims=[3])).to(device)
            output_b = model(second_image, coefficient)
            loss, parts = combined_loss(output_a, output_b, labels, styles, batch["source"], groups, group_dro, cfg)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["training"]["gradient_clip_norm"])
        scaler.step(optimizer)
        scaler.update()
        for key, value in parts.items():
            aggregate[key] = aggregate.get(key, 0.0) + value
    return {key: value / max(1, len(loader)) for key, value in aggregate.items()}


@torch.no_grad()
def predict(model, loader, device):
    model.eval()
    records = []
    for batch in loader:
        output = model(batch["image"].to(device), 0.0)
        for i in range(len(batch["label"])):
            records.append({
                "row_id": int(batch["row_id"][i]),
                "label": float(batch["label"][i]),
                "logit": float(output["logit"][i].cpu()),
                "probability": float(torch.sigmoid(output["logit"][i]).cpu()),
                "cue_logits": output["cue_logits"][i].cpu().tolist(),
                "reliability": output["reliability"][i].cpu().tolist(),
                "routing": output["routing"][i].cpu().tolist(),
                "duplicate_group": batch["duplicate_group"][i],
            })
    return records


class CheckpointSelector:
    def __init__(self, minimum_improvement: float = 0.001, patience: int = 5):
        self.minimum_improvement = minimum_improvement
        self.patience = patience
        self.best = None
        self.stale = 0

    def update(self, epoch: int, auroc: float, nll: float, state: dict) -> bool:
        candidate = (auroc, -nll, -epoch)
        improved = self.best is None or auroc >= self.best[0][0] + self.minimum_improvement
        exact_tie = self.best is not None and abs(auroc - self.best[0][0]) < self.minimum_improvement and candidate > self.best[0]
        if improved or exact_tie:
            self.best = (candidate, epoch, {k: v.detach().cpu().clone() for k, v in state.items()})
            self.stale = 0
        else:
            self.stale += 1
        return self.stale >= self.patience


def save_jsonl(path: str | Path, records: Iterable[dict]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True) + "\n")
