from __future__ import annotations

import math
import torch
from torch import nn
from torch.nn import functional as F


def bernoulli_js_from_logits(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    pa = torch.sigmoid(a).clamp(1e-6, 1 - 1e-6)
    pb = torch.sigmoid(b).clamp(1e-6, 1 - 1e-6)
    p = torch.stack([pa, 1 - pa], dim=-1)
    q = torch.stack([pb, 1 - pb], dim=-1)
    m = 0.5 * (p + q)
    kl_pm = (p * (p.log() - m.log())).sum(dim=-1)
    kl_qm = (q * (q.log() - m.log())).sum(dim=-1)
    return 0.5 * (kl_pm + kl_qm)


def reliability_targets(cue_logits_a: torch.Tensor, cue_logits_b: torch.Tensor) -> torch.Tensor:
    js = bernoulli_js_from_logits(cue_logits_a, cue_logits_b)
    return (1.0 - js / math.log(2.0)).clamp(0.0, 1.0).detach()


def cross_style_supervised_contrastive(
    features: torch.Tensor,
    labels: torch.Tensor,
    styles: torch.Tensor,
    sources: list[str] | tuple[str, ...],
    temperature: float = 0.1,
) -> torch.Tensor:
    features = F.normalize(features, dim=-1)
    logits = features @ features.t() / temperature
    batch = features.size(0)
    eye = torch.eye(batch, device=features.device, dtype=torch.bool)
    same_label = labels[:, None].eq(labels[None, :])
    different_style = styles[:, None].ne(styles[None, :])
    positive = same_label & different_style & ~eye
    source_map = {name: index for index, name in enumerate(sorted(set(sources)))}
    source_tensor = torch.tensor([source_map[x] for x in sources], device=features.device)
    ai = labels.bool()
    preferred = positive & ai[:, None] & source_tensor[:, None].ne(source_tensor[None, :])
    positive = torch.where(preferred.any(dim=1, keepdim=True), preferred, positive)
    logits = logits - logits.max(dim=1, keepdim=True).values.detach()
    denominator = torch.logsumexp(logits.masked_fill(eye, float("-inf")), dim=1)
    log_prob = logits - denominator[:, None]
    counts = positive.sum(dim=1)
    valid = counts > 0
    if not valid.any():
        return features.sum() * 0.0
    return -(log_prob.masked_fill(~positive, 0.0).sum(dim=1)[valid] / counts[valid]).mean()


class GroupDRO(nn.Module):
    def __init__(self, group_count: int, eta: float = 0.01):
        super().__init__()
        self.eta = eta
        self.register_buffer("weights", torch.ones(group_count) / group_count)

    @torch.no_grad()
    def update(self, group_loss: torch.Tensor, observed: torch.Tensor) -> None:
        update = torch.zeros_like(self.weights)
        update[observed] = group_loss[observed]
        self.weights.mul_(torch.exp(self.eta * update))
        self.weights.div_(self.weights.sum())

    def forward(self, per_item_loss: torch.Tensor, group_index: torch.Tensor) -> torch.Tensor:
        group_loss = torch.zeros_like(self.weights)
        observed = torch.zeros_like(self.weights, dtype=torch.bool)
        for group in group_index.unique():
            mask = group_index == group
            group_loss[group] = per_item_loss[mask].mean()
            observed[group] = True
        self.update(group_loss.detach(), observed)
        return (self.weights * group_loss).sum()


def combined_loss(
    output_a: dict[str, torch.Tensor],
    output_b: dict[str, torch.Tensor],
    labels: torch.Tensor,
    styles: torch.Tensor,
    sources: list[str] | tuple[str, ...],
    groups: torch.Tensor,
    group_dro: GroupDRO,
    cfg: dict,
) -> tuple[torch.Tensor, dict[str, float]]:
    weights = cfg["training"]["loss_weights"]
    per_item = F.binary_cross_entropy_with_logits(output_a["logit"], labels, reduction="none")
    ablation = cfg.get("ablation", {})
    authenticity = group_dro(per_item, groups) if ablation.get("group_dro", True) else per_item.mean()
    target = reliability_targets(output_a["cue_logits"], output_b["cue_logits"])
    reliability = F.mse_loss(output_a["reliability"], target) if ablation.get("reliability_target", True) else authenticity * 0.0
    contrastive = cross_style_supervised_contrastive(
        output_a["projection"], labels.long(), styles, sources, cfg["training"]["contrastive_temperature"]
    ) if ablation.get("cross_style_contrast", True) else authenticity * 0.0
    valid_style = styles >= 0
    style = F.cross_entropy(output_a["style_logits"][valid_style], styles[valid_style]) if valid_style.any() and ablation.get("style_adversary", True) else authenticity * 0.0
    load = ((output_a["routing"].mean(dim=0) - 1.0 / 3.0) ** 2).sum()
    balance = F.binary_cross_entropy_with_logits(output_a["cue_logits"], labels[:, None].expand_as(output_a["cue_logits"]))
    total = (
        authenticity
        + weights["reliability"] * reliability
        + weights["contrastive"] * contrastive
        + weights["style"] * style
        + weights["balance"] * balance
        + weights["routing_load"] * load
    )
    parts = {name: float(value.detach()) for name, value in {
        "total": total, "authenticity": authenticity, "reliability": reliability,
        "contrastive": contrastive, "style": style, "balance": balance, "routing_load": load,
    }.items()}
    return total, parts
