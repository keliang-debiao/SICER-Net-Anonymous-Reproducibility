from __future__ import annotations

from contextlib import contextmanager
from typing import Any

import torch
from torch import nn
from torch.autograd import Function
from torch.nn import functional as F
from transformers import CLIPVisionModelWithProjection

from .cues import CueConstructor, ClipNormalize


class GradientReverse(Function):
    @staticmethod
    def forward(ctx, x: torch.Tensor, coefficient: float):
        ctx.coefficient = coefficient
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        return -ctx.coefficient * grad_output, None


class ResidualAdapter(nn.Module):
    def __init__(self, input_dim: int = 768, width: int = 256):
        super().__init__()
        self.down = nn.Linear(input_dim, width)
        self.activation = nn.GELU()
        self.up = nn.Linear(width, input_dim)
        nn.init.xavier_uniform_(self.down.weight)
        nn.init.zeros_(self.down.bias)
        nn.init.zeros_(self.up.weight)
        nn.init.zeros_(self.up.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.up(self.activation(self.down(x)))


class CueAdaptedClip(nn.Module):
    cue_names = ("rgb", "hf", "ci")

    def __init__(self, checkpoint: str, adapter_width: int = 256, adapter_blocks: int = 4):
        super().__init__()
        self.backbone = CLIPVisionModelWithProjection.from_pretrained(checkpoint)
        for parameter in self.backbone.parameters():
            parameter.requires_grad = False
        self.adapter_blocks = adapter_blocks
        self.adapters = nn.ModuleDict({
            cue: nn.ModuleList([ResidualAdapter(768, adapter_width) for _ in range(adapter_blocks)])
            for cue in self.cue_names
        })
        self.active_cue: str | None = None
        self._handles = []
        selected = self.backbone.vision_model.encoder.layers[-adapter_blocks:]
        for local_index, layer in enumerate(selected):
            self._handles.append(layer.register_forward_hook(self._hook(local_index)))

    def _hook(self, local_index: int):
        def apply_adapter(module, inputs, output):
            if self.active_cue is None:
                return output
            adapter = self.adapters[self.active_cue][local_index]
            if isinstance(output, tuple):
                return (adapter(output[0]), *output[1:])
            return adapter(output)
        return apply_adapter

    @contextmanager
    def select_cue(self, cue: str):
        if cue not in self.cue_names:
            raise KeyError(cue)
        previous = self.active_cue
        self.active_cue = cue
        try:
            yield
        finally:
            self.active_cue = previous

    def forward(self, pixel_values: torch.Tensor, cue: str) -> torch.Tensor:
        with self.select_cue(cue):
            output = self.backbone(pixel_values=pixel_values)
        return output.image_embeds


class ReliabilityRouter(nn.Module):
    def __init__(self, feature_dim: int = 512, routing_dim: int = 256, beta: float = 0.75, temperature: float = 0.5):
        super().__init__()
        self.beta = beta
        self.temperature = temperature
        self.project = nn.ModuleDict({name: nn.Linear(feature_dim, routing_dim) for name in ("rgb", "hf", "ci")})
        self.align = nn.ModuleDict({name: nn.Linear(feature_dim, feature_dim) for name in ("rgb", "hf", "ci")})
        self.expert_embedding = nn.Parameter(torch.empty(3, routing_dim))
        nn.init.normal_(self.expert_embedding, std=0.02)

    def forward(self, representations: dict[str, torch.Tensor], reliability: torch.Tensor, cue_mask: torch.Tensor | None = None, mean_fusion: bool = False) -> tuple[torch.Tensor, torch.Tensor]:
        names = ("rgb", "hf", "ci")
        scores = []
        aligned = []
        for index, name in enumerate(names):
            projected = F.normalize(self.project[name](representations[name]), dim=-1)
            expert = F.normalize(self.expert_embedding[index], dim=-1)
            compatibility = (projected * expert).sum(dim=-1)
            scores.append(compatibility + self.beta * torch.log(reliability[:, index].clamp_min(1e-6)))
            aligned.append(self.align[name](representations[name]))
        score_tensor = torch.stack(scores, dim=1) / self.temperature
        if cue_mask is not None:
            score_tensor = score_tensor.masked_fill(~cue_mask[None, :], float("-inf"))
        if mean_fusion:
            base = cue_mask.float() if cue_mask is not None else torch.ones(3, device=score_tensor.device)
            weights = (base / base.sum()).unsqueeze(0).expand(score_tensor.size(0), -1)
        else:
            weights = torch.softmax(score_tensor, dim=1)
        fused = sum(weights[:, i:i+1] * aligned[i] for i in range(3))
        return fused, weights


class SICERNet(nn.Module):
    def __init__(self, cfg: dict[str, Any]):
        super().__init__()
        pcfg, mcfg = cfg["preprocessing"], cfg["model"]
        self.ablation = cfg.get("ablation", {})
        self.cues = CueConstructor(
            image_size=cfg["data"]["image_size"],
            epsilon=pcfg["chromatic_epsilon"],
            kernel_size=pcfg["chromatic_kernel_size"],
            sigma=pcfg["chromatic_sigma"],
        )
        self.normalize = ClipNormalize(pcfg["clip_mean"], pcfg["clip_std"])
        self.encoder = CueAdaptedClip(mcfg["backbone"], mcfg["adapter_width"], mcfg["adapter_blocks"])
        dim = mcfg["feature_dim"]
        hidden = mcfg["reliability_hidden"]
        dropout = mcfg["head_dropout"]
        self.cue_heads = nn.ModuleDict({name: nn.Linear(dim, 1) for name in ("rgb", "hf", "ci")})
        self.reliability_heads = nn.ModuleDict({
            name: nn.Sequential(nn.Linear(dim, hidden), nn.GELU(), nn.Dropout(dropout), nn.Linear(hidden, 1), nn.Sigmoid())
            for name in ("rgb", "hf", "ci")
        })
        self.router = ReliabilityRouter(dim, mcfg["routing_dim"], mcfg["routing_beta"], mcfg["routing_temperature"])
        self.authenticity_head = nn.Linear(dim, 1)
        self.style_head = nn.Sequential(
            nn.Linear(dim, mcfg["style_hidden"]), nn.GELU(), nn.Dropout(dropout), nn.Linear(mcfg["style_hidden"], mcfg["style_classes"])
        )
        self.projection_head = nn.Sequential(
            nn.Linear(dim, mcfg["projection_hidden"]), nn.GELU(), nn.Linear(mcfg["projection_hidden"], mcfg["projection_dim"])
        )
        active = [True, self.ablation.get("high_frequency", True), self.ablation.get("chromatic", True)]
        self.active_cues = tuple(active)
        self.register_buffer("cue_mask", torch.tensor(active, dtype=torch.bool), persistent=False)
        for name, enabled in zip(("rgb", "hf", "ci"), active):
            if not enabled:
                for module in (self.encoder.adapters[name], self.cue_heads[name], self.reliability_heads[name]):
                    for parameter in module.parameters():
                        parameter.requires_grad = False
        if self.ablation.get("routing", "reliability") == "mean":
            for parameter in self.router.parameters():
                parameter.requires_grad = False
        if not self.ablation.get("style_adversary", True):
            for parameter in self.style_head.parameters():
                parameter.requires_grad = False
        if not self.ablation.get("cross_style_contrast", True):
            for parameter in self.projection_head.parameters():
                parameter.requires_grad = False

    def encode_cues(self, rgb: torch.Tensor) -> dict[str, torch.Tensor]:
        cues = self.cues(rgb)
        output = {}
        for index, (name, value) in enumerate(cues.items()):
            if self.active_cues[index]:
                output[name] = self.encoder(self.normalize(value), name)
            else:
                output[name] = torch.zeros(rgb.size(0), self.authenticity_head.in_features, device=rgb.device, dtype=rgb.dtype)
        return output

    def forward(self, rgb: torch.Tensor, gradient_reverse_coefficient: float = 0.0) -> dict[str, torch.Tensor]:
        representations = self.encode_cues(rgb)
        cue_logits = torch.cat([self.cue_heads[name](representations[name]) for name in ("rgb", "hf", "ci")], dim=1)
        reliability = torch.cat([self.reliability_heads[name](representations[name]) for name in ("rgb", "hf", "ci")], dim=1)
        fused, routing = self.router(
            representations,
            reliability,
            cue_mask=self.cue_mask,
            mean_fusion=self.ablation.get("routing", "reliability") == "mean",
        )
        logit = self.authenticity_head(fused).squeeze(1)
        reversed_fused = GradientReverse.apply(fused, gradient_reverse_coefficient)
        style_logits = self.style_head(reversed_fused)
        projection = F.normalize(self.projection_head(fused), dim=-1)
        return {
            "logit": logit,
            "cue_logits": cue_logits,
            "reliability": reliability,
            "routing": routing,
            "fused": fused,
            "style_logits": style_logits,
            "projection": projection,
        }
