from __future__ import annotations

import numpy as np
from scipy.stats import t, binomtest
from sklearn.metrics import roc_auc_score


def fold_mean_sd_ci(values, confidence: float = 0.95):
    values = np.asarray(values, dtype=float)
    mean = values.mean()
    sd = values.std(ddof=1)
    margin = t.ppf((1 + confidence) / 2, df=len(values) - 1) * sd / np.sqrt(len(values))
    return float(mean), float(sd), (float(mean - margin), float(mean + margin))


def holm_adjust(p_values):
    p_values = np.asarray(p_values, dtype=float)
    order = np.argsort(p_values)
    adjusted = np.empty_like(p_values)
    running = 0.0
    count = len(p_values)
    for rank, idx in enumerate(order):
        running = max(running, min(1.0, (count - rank) * p_values[idx]))
        adjusted[idx] = running
    return adjusted


def paired_hierarchical_bootstrap_auc(
    labels, prob_a, prob_b, components, seeds=None, replicates: int = 10000, random_seed: int = 2026
):
    labels = np.asarray(labels)
    prob_a = np.asarray(prob_a)
    prob_b = np.asarray(prob_b)
    components = np.asarray(components)
    rng = np.random.default_rng(random_seed)
    differences = []
    classes = np.unique(labels)
    component_by_class = {c: np.unique(components[labels == c]) for c in classes}
    for _ in range(replicates):
        indices = []
        for cls in classes:
            pool = component_by_class[cls]
            sampled = rng.choice(pool, size=len(pool), replace=True)
            for component in sampled:
                candidates = np.flatnonzero((components == component) & (labels == cls))
                indices.extend(candidates.tolist())
        index = np.asarray(indices, dtype=int)
        differences.append(roc_auc_score(labels[index], prob_a[index]) - roc_auc_score(labels[index], prob_b[index]))
    differences = np.asarray(differences)
    ci = tuple(np.quantile(differences, [0.025, 0.975]).tolist())
    p = 2 * min((differences <= 0).mean(), (differences >= 0).mean())
    return float(differences.mean()), ci, float(min(1.0, p))


def paired_sign_flip(differences, replicates: int = 10000, random_seed: int = 2026):
    differences = np.asarray(differences, dtype=float)
    observed = abs(differences.mean())
    rng = np.random.default_rng(random_seed)
    permuted = []
    for _ in range(replicates):
        signs = rng.choice([-1.0, 1.0], size=len(differences))
        permuted.append(abs((differences * signs).mean()))
    return float((np.sum(np.asarray(permuted) >= observed) + 1) / (replicates + 1))


def exact_mcnemar(pred_a, pred_b, labels):
    pred_a, pred_b, labels = map(np.asarray, (pred_a, pred_b, labels))
    correct_a, correct_b = pred_a == labels, pred_b == labels
    b = int(np.sum(correct_a & ~correct_b))
    c = int(np.sum(~correct_a & correct_b))
    if b + c == 0:
        return 1.0
    return float(binomtest(min(b, c), b + c, 0.5, alternative="two-sided").pvalue)
