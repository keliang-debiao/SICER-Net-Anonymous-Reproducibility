from __future__ import annotations

import io
import torch
from PIL import Image
from torchvision.transforms import InterpolationMode
from torchvision.transforms import functional as TF


def jpeg_batch(images: torch.Tensor, quality: int) -> torch.Tensor:
    restored = []
    for tensor in images.detach().cpu():
        image = TF.to_pil_image(tensor.clamp(0, 1))
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=quality)
        buffer.seek(0)
        restored.append(TF.pil_to_tensor(Image.open(buffer).convert("RGB")).float().div(255.0))
    return torch.stack(restored).to(images.device)


def gaussian_noise(images: torch.Tensor, sigma: float) -> torch.Tensor:
    return (images + torch.randn_like(images) * sigma).clamp(0, 1)


def gaussian_blur(images: torch.Tensor, kernel_size: int) -> torch.Tensor:
    sigma = {3: 0.8, 5: 1.1, 7: 1.4}[kernel_size]
    return TF.gaussian_blur(images, kernel_size=[kernel_size, kernel_size], sigma=[sigma, sigma])


def downsample(images: torch.Tensor, side: int) -> torch.Tensor:
    small = TF.resize(images, [side, side], interpolation=InterpolationMode.BICUBIC, antialias=True)
    return TF.resize(small, [224, 224], interpolation=InterpolationMode.BICUBIC, antialias=True)


def center_area_crop(images: torch.Tensor, retained_area: float) -> torch.Tensor:
    side = int(round(224 * retained_area ** 0.5))
    top = (224 - side) // 2
    left = (224 - side) // 2
    cropped = TF.crop(images, top, left, side, side)
    return TF.resize(cropped, [224, 224], interpolation=InterpolationMode.BICUBIC, antialias=True)


PERTURBATION_GRID = {
    "jpeg": [90, 70, 50, 30],
    "gaussian_noise": [0.01, 0.02, 0.03],
    "gaussian_blur": [3, 5, 7],
    "downsample": [192, 128, 96],
    "center_crop": [0.90, 0.75, 0.60],
}
