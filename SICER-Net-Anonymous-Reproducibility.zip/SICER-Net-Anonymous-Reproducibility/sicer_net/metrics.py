from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    average_precision_score, balanced_accuracy_score, brier_score_loss,
    f1_score, log_loss, recall_score, roc_auc_score,
)


def expected_calibration_error(labels, probabilities, bins: int = 15) -> float:
    labels = np.asarray(labels)
    probabilities = np.asarray(probabilities)
    order = np.argsort(probabilities)
    partitions = np.array_split(order, bins)
    total = len(labels)
    value = 0.0
    for index in partitions:
        if len(index) == 0:
            continue
        value += len(index) / total * abs(labels[index].mean() - probabilities[index].mean())
    return float(value)


def calibration_intercept_slope(labels, probabilities) -> tuple[float, float]:
    from sklearn.linear_model import LogisticRegression
    probabilities = np.clip(np.asarray(probabilities), 1e-6, 1 - 1e-6)
    logits = np.log(probabilities / (1 - probabilities)).reshape(-1, 1)
    model = LogisticRegression(C=1e6, solver="lbfgs").fit(logits, labels)
    return float(model.intercept_[0]), float(model.coef_[0, 0])


def binary_metrics(labels, probabilities, threshold: float = 0.48, bins: int = 15) -> dict[str, float]:
    labels = np.asarray(labels).astype(int)
    probabilities = np.asarray(probabilities)
    predictions = (probabilities >= threshold).astype(int)
    intercept, slope = calibration_intercept_slope(labels, probabilities)
    return {
        "auroc": float(roc_auc_score(labels, probabilities)),
        "auprc": float(average_precision_score(labels, probabilities)),
        "macro_f1": float(f1_score(labels, predictions, average="macro")),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predictions)),
        "ai_recall": float(recall_score(labels, predictions, pos_label=1)),
        "brier": float(brier_score_loss(labels, probabilities)),
        "nll": float(log_loss(labels, probabilities, labels=[0, 1])),
        "ece": expected_calibration_error(labels, probabilities, bins),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
    }


def select_threshold(labels, probabilities, step: float = 0.001) -> float:
    candidates = np.arange(0.0, 1.0 + step / 2, step)
    scored = []
    for threshold in candidates:
        prediction = np.asarray(probabilities) >= threshold
        macro = f1_score(labels, prediction, average="macro")
        balanced = balanced_accuracy_score(labels, prediction)
        scored.append((macro, balanced, -abs(threshold - 0.5), threshold))
    return float(max(scored)[-1])
