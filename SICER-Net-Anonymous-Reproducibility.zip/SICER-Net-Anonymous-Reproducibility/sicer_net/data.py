from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Iterable
import io
import random

import imagehash
import numpy as np
import pandas as pd
import torch
from PIL import Image
from sklearn.model_selection import StratifiedGroupKFold, StratifiedShuffleSplit
from torch.utils.data import Dataset
from torchvision.transforms import InterpolationMode
from torchvision.transforms import functional as TF
from torchvision import transforms


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def file_sha256(path: Path, block_size: int = 1 << 20) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def inspect_image(path: Path) -> tuple[str, str, int, int]:
    digest = file_sha256(path)
    with Image.open(path) as image:
        image = image.convert("RGB")
        image.load()
        perceptual = str(imagehash.phash(image))
        width, height = image.size
    return digest, perceptual, width, height


def _hash_distance(a: str, b: str) -> int:
    return imagehash.hex_to_hash(a) - imagehash.hex_to_hash(b)


class BKTree:
    def __init__(self):
        self.root = None

    def add(self, value: str, index: int) -> None:
        if self.root is None:
            self.root = [value, [index], {}]
            return
        node = self.root
        while True:
            distance = _hash_distance(value, node[0])
            if distance == 0:
                node[1].append(index)
                return
            if distance not in node[2]:
                node[2][distance] = [value, [index], {}]
                return
            node = node[2][distance]

    def query(self, value: str, maximum_distance: int):
        if self.root is None:
            return []
        matches, stack = [], [self.root]
        while stack:
            node = stack.pop()
            distance = _hash_distance(value, node[0])
            if distance <= maximum_distance:
                matches.extend(node[1])
            lower, upper = distance - maximum_distance, distance + maximum_distance
            stack.extend(child for edge, child in node[2].items() if lower <= edge <= upper)
        return matches


def assign_duplicate_components(frame: pd.DataFrame, maximum_distance: int = 4) -> pd.Series:
    uf = UnionFind(len(frame))
    by_exact: dict[str, list[int]] = defaultdict(list)
    for i, digest in enumerate(frame["sha256"]):
        by_exact[digest].append(i)
    for members in by_exact.values():
        for idx in members[1:]:
            uf.union(members[0], idx)

    tree = BKTree()
    for i, value in enumerate(frame["phash"]):
        for j in tree.query(value, maximum_distance):
            uf.union(i, j)
        tree.add(value, i)
    roots = [uf.find(i) for i in range(len(frame))]
    mapping = {root: f"dup_{rank:08d}" for rank, root in enumerate(sorted(set(roots)))}
    return pd.Series([mapping[root] for root in roots], index=frame.index)


def audit_manifest(manifest_path: Path, root: Path, maximum_distance: int) -> pd.DataFrame:
    frame = pd.read_csv(manifest_path)
    rows = []
    for row in frame.itertuples(index=False):
        path = root / row.filepath
        digest, perceptual, width, height = inspect_image(path)
        rows.append((digest, perceptual, width, height))
    frame[["sha256", "phash", "width", "height"]] = pd.DataFrame(rows, index=frame.index)
    frame["duplicate_group"] = assign_duplicate_components(frame, maximum_distance)
    return frame


def cross_corpus_overlaps(development: pd.DataFrame, external: pd.DataFrame, maximum_distance: int = 4) -> pd.DataFrame:
    tree = BKTree()
    for index, value in enumerate(development["phash"]):
        tree.add(value, index)
    exact = defaultdict(list)
    for index, digest in enumerate(development["sha256"]):
        exact[digest].append(index)
    records = []
    for external_index, row in external.iterrows():
        candidates = set(exact.get(row.sha256, []))
        candidates.update(tree.query(row.phash, maximum_distance))
        for development_index in sorted(candidates):
            distance = _hash_distance(row.phash, development.iloc[development_index].phash)
            if row.sha256 == development.iloc[development_index].sha256 or distance <= maximum_distance:
                records.append({
                    "development_index": int(development_index),
                    "external_index": int(external_index),
                    "exact_match": bool(row.sha256 == development.iloc[development_index].sha256),
                    "phash_distance": int(distance),
                })
    return pd.DataFrame(records, columns=["development_index", "external_index", "exact_match", "phash_distance"])


def add_grouped_folds(frame: pd.DataFrame, folds: int = 5, seed: int = 17) -> pd.DataFrame:
    required = {"label", "style", "source", "duplicate_group"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    target = frame["style"].astype(str) + "__" + frame["source"].astype(str)
    splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed)
    output = frame.copy()
    output["fold"] = -1
    for fold, (_, held_out) in enumerate(splitter.split(output, target, output["duplicate_group"])):
        output.loc[output.index[held_out], "fold"] = fold
    leakage = output.groupby("duplicate_group")["fold"].nunique().max()
    if leakage != 1:
        raise RuntimeError("A duplicate component crosses outer folds")
    return output


def grouped_early_stop_split(frame: pd.DataFrame, fraction: float, seed: int) -> tuple[np.ndarray, np.ndarray]:
    groups = frame[["duplicate_group", "style", "source"]].drop_duplicates("duplicate_group")
    strata = groups["style"].astype(str) + "__" + groups["source"].astype(str)
    splitter = StratifiedShuffleSplit(n_splits=1, test_size=fraction, random_state=seed)
    fit_idx, stop_idx = next(splitter.split(groups, strata))
    fit_groups = set(groups.iloc[fit_idx]["duplicate_group"])
    stop_groups = set(groups.iloc[stop_idx]["duplicate_group"])
    fit_rows = np.flatnonzero(frame["duplicate_group"].isin(fit_groups).to_numpy())
    stop_rows = np.flatnonzero(frame["duplicate_group"].isin(stop_groups).to_numpy())
    return fit_rows, stop_rows


class ImageManifestDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, root: str | Path, image_size: int = 224, training: bool = False, preprocessing: dict | None = None):
        self.frame = frame.reset_index(drop=True)
        self.root = Path(root)
        self.image_size = image_size
        self.training = training
        self.preprocessing = preprocessing or {}
        self.source_index = {"human": 0, "ldm": 1, "sd21": 2}

    def __len__(self) -> int:
        return len(self.frame)

    def _deterministic_image(self, image: Image.Image) -> torch.Tensor:
        image = TF.resize(image, 256, interpolation=InterpolationMode.BICUBIC, antialias=True)
        image = TF.center_crop(image, [self.image_size, self.image_size])
        return TF.pil_to_tensor(image).float().div(255.0)

    def _jpeg(self, image: Image.Image) -> Image.Image:
        quality_range = self.preprocessing.get("jpeg_quality", [80, 100])
        quality = random.randint(int(quality_range[0]), int(quality_range[1]))
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=quality)
        buffer.seek(0)
        result = Image.open(buffer).convert("RGB")
        result.load()
        return result

    def _weak_view(self, image: Image.Image) -> torch.Tensor:
        scale = self.preprocessing.get("train_crop_scale", [0.90, 1.00])
        ratio = self.preprocessing.get("train_aspect_ratio", [0.95, 1.05])
        top, left, height, width = transforms.RandomResizedCrop.get_params(image, scale=scale, ratio=ratio)
        view = TF.resized_crop(image, top, left, height, width, [self.image_size, self.image_size], InterpolationMode.BICUBIC, antialias=True)
        if random.random() < self.preprocessing.get("horizontal_flip_probability", 0.5):
            view = TF.hflip(view)
        if random.random() < self.preprocessing.get("color_jitter_probability", 0.5):
            jitter = transforms.ColorJitter(
                brightness=self.preprocessing.get("brightness", 0.1),
                contrast=self.preprocessing.get("contrast", 0.1),
                saturation=self.preprocessing.get("saturation", 0.1),
                hue=self.preprocessing.get("hue", 0.02),
            )
            view = jitter(view)
        if random.random() < self.preprocessing.get("jpeg_probability", 0.5):
            view = self._jpeg(view)
        return TF.pil_to_tensor(view).float().div(255.0)

    def __getitem__(self, index: int) -> dict[str, object]:
        row = self.frame.iloc[index]
        with Image.open(self.root / row.filepath) as image:
            image = image.convert("RGB")
            if self.training:
                tensor = self._weak_view(image)
                tensor_b = self._weak_view(image)
            else:
                tensor = self._deterministic_image(image)
                tensor_b = None
        style = int(row.style) if "style" in self.frame.columns and not pd.isna(row.style) else -1
        source = str(row.source) if "source" in self.frame.columns else "unknown"
        item = {
            "image": tensor,
            "label": torch.tensor(float(row.label), dtype=torch.float32),
            "style": torch.tensor(style, dtype=torch.long),
            "source": source,
            "group_index": torch.tensor(style * 3 + self.source_index.get(source, 0) if style >= 0 else 0, dtype=torch.long),
            "duplicate_group": str(row.duplicate_group),
            "row_id": int(row.row_id) if "row_id" in self.frame.columns else int(index),
        }
        if tensor_b is not None:
            item["image_b"] = tensor_b
        return item
