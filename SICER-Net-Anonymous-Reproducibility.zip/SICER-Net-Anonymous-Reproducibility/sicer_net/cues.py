from __future__ import annotations

import math
import torch
from torch import nn
from torch.nn import functional as F


def _gaussian_kernel(size: int, sigma: float, device, dtype) -> torch.Tensor:
    axis = torch.arange(size, device=device, dtype=dtype) - (size - 1) / 2
    kernel_1d = torch.exp(-(axis.square()) / (2 * sigma * sigma))
    kernel_1d = kernel_1d / kernel_1d.sum()
    kernel_2d = torch.outer(kernel_1d, kernel_1d)
    return kernel_2d.expand(3, 1, size, size).contiguous()


class CueConstructor(nn.Module):
    def __init__(self, image_size: int = 224, epsilon: float = 1e-6, kernel_size: int = 5, sigma: float = 1.0):
        super().__init__()
        self.image_size = image_size
        self.epsilon = epsilon
        self.kernel_size = kernel_size
        self.sigma = sigma
        filters = torch.tensor([
            [[1.0, -1.0], [1.0, -1.0]],
            [[1.0, 1.0], [-1.0, -1.0]],
            [[1.0, -1.0], [-1.0, 1.0]],
        ]) * 0.5
        self.register_buffer("haar_filters", filters.unsqueeze(1), persistent=False)

    def high_frequency(self, rgb: torch.Tensor) -> torch.Tensor:
        luminance = 0.299 * rgb[:, 0:1] + 0.587 * rgb[:, 1:2] + 0.114 * rgb[:, 2:3]
        luminance = F.pad(luminance, (0, 1, 0, 1), mode="reflect")
        details = F.conv2d(luminance, self.haar_filters.to(rgb), stride=2)
        details = ((details + 1.0) * 0.5).clamp(0.0, 1.0)
        return F.interpolate(details, size=(self.image_size, self.image_size), mode="bilinear", align_corners=False)

    def chromatic(self, rgb: torch.Tensor) -> torch.Tensor:
        chroma = rgb / (rgb.sum(dim=1, keepdim=True) + self.epsilon)
        kernel = _gaussian_kernel(self.kernel_size, self.sigma, rgb.device, rgb.dtype)
        pad = self.kernel_size // 2
        smooth = F.conv2d(F.pad(chroma, (pad, pad, pad, pad), mode="reflect"), kernel, groups=3)
        return (0.5 + 0.5 * (chroma - smooth)).clamp(0.0, 1.0)

    def forward(self, rgb: torch.Tensor) -> dict[str, torch.Tensor]:
        return {"rgb": rgb, "hf": self.high_frequency(rgb), "ci": self.chromatic(rgb)}


class ClipNormalize(nn.Module):
    def __init__(self, mean: list[float], std: list[float]):
        super().__init__()
        self.register_buffer("mean", torch.tensor(mean).view(1, 3, 1, 1), persistent=False)
        self.register_buffer("std", torch.tensor(std).view(1, 3, 1, 1), persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return (x - self.mean) / self.std
