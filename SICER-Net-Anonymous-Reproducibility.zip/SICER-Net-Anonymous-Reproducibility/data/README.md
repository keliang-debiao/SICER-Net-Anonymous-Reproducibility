# Data Layout and Manifest Contract

Dataset content is not redistributed. Download the two public Kaggle releases and keep them under the ignored `data/raw/` directory.

## Public sources

- `data/raw/ai_artbench`: Kaggle identifier `ravidussilva/real-ai-art`
- `data/raw/ai_vs_human`: Kaggle identifier `alessandrasala79/ai-vs-human-generated-dataset`

## Development manifest

`data/processed/development_manifest.csv` must contain:

| Column | Type | Definition |
|---|---|---|
| `filepath` | string | Path relative to the development root |
| `label` | integer | `0` human-created, `1` AI-generated |
| `style` | integer | Index `0` through `9` |
| `source` | string | `human`, `ldm`, or `sd21` |
| `sha256` | string | Exact-file digest added by the audit script |
| `phash` | string | Perceptual hash added by the audit script |
| `duplicate_group` | string | Connected-component identifier |
| `fold` | integer | Outer fold `0` through `4` added by the split script |

## External manifest

`data/processed/external_manifest.csv` uses `filepath`, `label`, `sha256`, `phash`, and `duplicate_group`. Style and generator identity are not required because the external release does not provide harmonized labels.

## Integrity rules

1. Decode every image before partitioning.
2. Confirm that directory-derived labels match manifest labels.
3. Link files with identical SHA-256 or perceptual-hash distance at most four.
4. Assign each connected component to one outer fold.
5. Remove or quarantine any cross-corpus duplicate component before external evaluation.
6. Do not expose file paths, EXIF fields, generation seeds, or directory names to the predictor.
