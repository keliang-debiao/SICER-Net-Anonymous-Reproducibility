# Provenance of Reference Records

The files in this directory were assembled from values reported in the manuscript tables. They are provided to verify parsing, aggregation, table generation, and consistency checks before access to the public datasets and GPU training environment.

They are not outputs produced by a new execution of the training pipeline in this workspace. A genuine run must write to the ignored `artifacts/` directory and must preserve its own timestamps, software versions, dataset digests, checkpoints, and prediction files.

The reference records must not be cited as independent empirical evidence. Their role is to make the expected report schema and manuscript-level targets explicit.
