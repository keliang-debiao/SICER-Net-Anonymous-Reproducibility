# Fixed Implementation Notes

The following operational settings make the manuscript equations map to one implementation.

## Cue construction

- Chromatic normalization stabilizer: `1e-6`.
- Gaussian kernel: `5 x 5`, standard deviation `1.0`, reflection padding.
- Chromatic residual mapping: `clip(0.5 + 0.5 * (chromaticity - GaussianBlur(chromaticity)), 0, 1)`.
- Haar transform: one level, symmetric extension, signed coefficient mapping, `LH-HL-HH` channel order.

## Trainable heads

- Cue authenticity head: `512 -> 1`.
- Reliability predictor: `512 -> 128 -> 1`, GELU, dropout `0.10`, sigmoid output.
- Cue alignment: `512 -> 512`.
- Routing compatibility: `512 -> 256` with three learned 256-dimensional expert embeddings.
- Contrastive projection: `512 -> 256 -> 128`, GELU, normalized output.
- Style classifier: `512 -> 128 -> 10`, GELU, dropout `0.10`.
- SBRC head: five inputs, `5 -> 16 -> 1`, GELU; output temperature bounded to `[0.7, 2.5]`.

## Optimization details

- Contrastive temperature: `0.10`.
- Group-DRO weights: uniform initialization; exponentiated-gradient rate `0.01`.
- Gradient-reversal schedule multiplier: linear increase from `0` to `1` during the first five epochs; the style-loss weight remains `0.05`.
- Final external training duration: the median best epoch from the five development outer folds, calculated separately for each seed; the final model is then fitted on the complete audited development corpus for that fixed duration.

These settings are held constant across folds, seeds, ablations, and external evaluation unless an ablation explicitly disables one component.
