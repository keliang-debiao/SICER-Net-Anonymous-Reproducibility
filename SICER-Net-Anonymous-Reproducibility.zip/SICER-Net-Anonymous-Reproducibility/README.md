# SICER-Net Anonymous Reproducibility Package

This repository implements the Style-Invariant Cue Expert Routing Network (SICER-Net) and the evaluation protocol reported in the associated manuscript. It is organized for anonymous peer review and contains no author, institution, or repository-owner identifiers.

## Scope

The package covers:

- integrity auditing with SHA-256 and perceptual-hash duplicate components;
- duplicate-aware grouped five-fold partitioning;
- RGB, one-level Haar high-frequency, and chromatic inconsistency cues;
- a frozen CLIP ViT-B/16 encoder with cue-specific residual adapters;
- reliability-conditioned cue routing;
- style-adversarial, cross-style contrastive, and group-DRO training;
- second-stage cross-fitted style-balanced reliability calibration;
- frozen zero-finetuning external evaluation;
- ablation, corruption, calibration, paired statistical, and efficiency analyses;
- table-ready CSV export and manuscript-aligned reference records.

## Environment

Python 3.11 and CUDA 12.x are recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## Data preparation

The study uses two public Kaggle datasets:

- development: `ravidussilva/real-ai-art`
- external validation: `alessandrasala79/ai-vs-human-generated-dataset`

Place downloaded content outside version control and construct manifests according to `data/README.md`.

```bash
python scripts/audit_data.py --config configs/main.yaml --dataset development
python scripts/audit_data.py --config configs/main.yaml --dataset external
python scripts/check_cross_corpus.py --config configs/main.yaml
python scripts/build_splits.py --config configs/main.yaml
```

## Main execution sequence

```bash
python scripts/train_cv.py --config configs/main.yaml
python scripts/run_baselines.py --config configs/main.yaml --plan
python scripts/fit_calibrators.py --config configs/main.yaml
python scripts/train_final.py --config configs/main.yaml
python scripts/evaluate_external.py --config configs/main.yaml
python scripts/run_ablations.py --config configs/main.yaml --matrix configs/ablations.yaml
python scripts/run_robustness.py --config configs/main.yaml
python scripts/run_statistics.py --config configs/main.yaml
python scripts/export_tables.py --config configs/main.yaml
```

The external dataset is read only after the development model, calibration rule, and threshold have been locked. No external label is used for training, checkpoint selection, normalization, calibration fitting, or threshold selection.

After both manifests are prepared, the same sequence can be launched with `bash run_pipeline.sh configs/main.yaml`.

## Review-time fast checks

```bash
python -m compileall -q sicer_net scripts tests
pytest -q
python scripts/validate_repository.py --root .
```

## Configuration boundary

`configs/main.yaml` is the single source of truth for fixed settings. The operational details that remove implementation ambiguity are recorded in `IMPLEMENTATION_NOTES.md`. Dataset paths may be changed locally; model, fitting, and evaluation settings should remain unchanged when reproducing the manuscript protocol.

## Reference records

`reference_records/` contains machine-readable values transcribed from the manuscript tables and execution-style records assembled from those values. Their provenance is stated in `reference_records/PROVENANCE.md`. They are supplied for pipeline validation and reporting checks and are not presented as outputs produced by a new training run in this workspace.

## Anonymity

No author names, affiliations, machine hostnames, absolute dataset paths, account names, or private URLs are stored. The package uses relative paths and public dataset identifiers only.
