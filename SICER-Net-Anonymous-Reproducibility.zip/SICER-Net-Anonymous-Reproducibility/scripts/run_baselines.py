#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import json

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier

from sicer_net.baselines import BASELINE_REGISTRY
from sicer_net.config import load_config


def feature_models():
    return {
        "logistic_regression": LogisticRegression(C=1.0, class_weight="balanced", max_iter=2000, n_jobs=1),
        "random_forest": RandomForestClassifier(n_estimators=500, max_features="sqrt", class_weight="balanced", n_jobs=-1, random_state=17),
        "xgboost": XGBClassifier(n_estimators=600, max_depth=6, learning_rate=0.05, eval_metric="logloss", n_jobs=-1, random_state=17),
    }


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--features")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    cfg = load_config(args.config)
    if args.plan:
        print(json.dumps({
            "feature_models": sorted(feature_models()),
            "image_models": sorted(BASELINE_REGISTRY),
            "folds": cfg["data"]["outer_folds"],
            "seeds": cfg["training"]["seeds"],
        }, indent=2))
        return
    if not args.features:
        raise SystemExit("Provide --features with columns label, fold, row_id, and feature_*")
    frame = pd.read_parquet(args.features) if str(args.features).endswith(".parquet") else pd.read_csv(args.features)
    feature_columns = [column for column in frame.columns if column.startswith("feature_")]
    if not feature_columns:
        raise ValueError("No feature_ columns found")
    records = []
    for name, model in feature_models().items():
        for fold in range(cfg["data"]["outer_folds"]):
            fit = frame[frame.fold != fold]
            held = frame[frame.fold == fold]
            model.fit(fit[feature_columns], fit.label)
            probability = model.predict_proba(held[feature_columns])[:, 1]
            records.extend({
                "model": name, "fold": fold, "row_id": int(row_id), "label": int(label), "probability": float(value)
            } for row_id, label, value in zip(held.row_id, held.label, probability))
    target = Path(cfg["project"]["output_root"]) / "baselines" / "feature_baseline_predictions.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(records).to_csv(target, index=False)
    print(f"rows={len(records)} output={target}")


if __name__ == "__main__":
    main()
