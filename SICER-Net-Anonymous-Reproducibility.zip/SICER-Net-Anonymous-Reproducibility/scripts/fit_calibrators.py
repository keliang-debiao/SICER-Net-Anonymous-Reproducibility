#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path

import pandas as pd
import torch

from sicer_net.calibration import GlobalTemperature, StyleBalancedReliabilityCalibrator
from sicer_net.config import load_config


def frame_to_tensors(frame):
    logits = torch.tensor(frame.logit.to_numpy(), dtype=torch.float32)
    labels = torch.tensor(frame.label.to_numpy(), dtype=torch.float32)
    reliability = torch.tensor(frame[["rho_rgb", "rho_hf", "rho_ci"]].to_numpy(), dtype=torch.float32)
    cue_logits = torch.tensor(frame[["logit_rgb", "logit_hf", "logit_ci"]].to_numpy(), dtype=torch.float32)
    return logits, labels, reliability, cue_logits


def new_sbrc(cfg):
    return StyleBalancedReliabilityCalibrator(
        cfg["calibration"]["minimum_temperature"],
        cfg["calibration"]["maximum_temperature"],
        cfg["calibration"]["hidden_units"],
    )


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--oof-root", default="artifacts/oof")
    args = parser.parse_args()
    cfg = load_config(args.config)
    paths = sorted(Path(args.oof_root).glob("seed_*_fold_*.csv"))
    if not paths:
        raise FileNotFoundError(f"No out-of-fold prediction files under {args.oof_root}")
    frame = pd.concat([pd.read_csv(path) for path in paths], ignore_index=True)
    output_root = Path(cfg["project"]["output_root"]) / "calibration"
    output_root.mkdir(parents=True, exist_ok=True)
    crossfit_records = []

    for seed in cfg["training"]["seeds"]:
        seed_frame = frame[frame.seed == seed].reset_index(drop=True)
        for held_out_fold in sorted(seed_frame.fold.unique()):
            fit = seed_frame[seed_frame.fold != held_out_fold]
            apply = seed_frame[seed_frame.fold == held_out_fold]
            logits, labels, reliability, cue_logits = frame_to_tensors(fit)
            sbrc = new_sbrc(cfg).fit(logits, reliability, cue_logits, labels)
            global_temperature = GlobalTemperature().fit(logits, labels)
            a_logits, _, a_rel, a_cues = frame_to_tensors(apply)
            p_sbrc = torch.sigmoid(sbrc(a_logits, a_rel, a_cues)).detach().numpy()
            p_global = torch.sigmoid(global_temperature(a_logits)).detach().numpy()
            for row_id, probability_sbrc, probability_global in zip(apply.row_id, p_sbrc, p_global):
                crossfit_records.append({
                    "row_id": int(row_id), "fold": int(held_out_fold), "seed": int(seed),
                    "probability_sbrc": float(probability_sbrc), "probability_global": float(probability_global),
                })

        logits, labels, reliability, cue_logits = frame_to_tensors(seed_frame)
        final_sbrc = new_sbrc(cfg).fit(logits, reliability, cue_logits, labels)
        final_global = GlobalTemperature().fit(logits, labels)
        torch.save({"state_dict": final_sbrc.state_dict(), "seed": seed}, output_root / f"sbrc_seed_{seed}.pt")
        torch.save({"state_dict": final_global.state_dict(), "seed": seed}, output_root / f"global_temperature_seed_{seed}.pt")

    pd.DataFrame(crossfit_records).to_csv(output_root / "internal_crossfit.csv", index=False)
    print(f"oof_rows={len(frame)} crossfit_rows={len(crossfit_records)} calibrators={len(cfg['training']['seeds'])}")


if __name__ == "__main__":
    main()
