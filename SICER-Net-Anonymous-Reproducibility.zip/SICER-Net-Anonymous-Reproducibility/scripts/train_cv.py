#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import json

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import log_loss, roc_auc_score
from torch.cuda.amp import GradScaler
from torch.utils.data import DataLoader

from sicer_net.config import load_config
from sicer_net.data import ImageManifestDataset, grouped_early_stop_split
from sicer_net.engine import CheckpointSelector, predict, set_seed, train_epoch
from sicer_net.losses import GroupDRO
from sicer_net.model import SICERNet


def loader(dataset, cfg, shuffle=False):
    return DataLoader(
        dataset,
        batch_size=cfg["training"]["batch_size"],
        shuffle=shuffle,
        num_workers=cfg["training"]["num_workers"],
        pin_memory=True,
        persistent_workers=cfg["training"]["num_workers"] > 0,
    )


def build_scheduler(optimizer, warmup_epochs, maximum_epochs):
    def multiplier(epoch):
        if epoch < warmup_epochs:
            return float(epoch + 1) / max(1, warmup_epochs)
        progress = (epoch - warmup_epochs) / max(1, maximum_epochs - warmup_epochs)
        return 0.5 * (1.0 + np.cos(np.pi * progress))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier)


def run_one(frame, fold, seed, cfg, device):
    set_seed(seed)
    train_frame = frame[frame.fold != fold].reset_index(drop=True)
    held_frame = frame[frame.fold == fold].reset_index(drop=True)
    fit_rows, stop_rows = grouped_early_stop_split(train_frame, cfg["data"]["early_stop_fraction"], seed)
    fit_frame, stop_frame = train_frame.iloc[fit_rows].copy(), train_frame.iloc[stop_rows].copy()
    root = cfg["data"]["development_root"]
    fit_data = ImageManifestDataset(fit_frame, root, cfg["data"]["image_size"], True, cfg["preprocessing"])
    stop_data = ImageManifestDataset(stop_frame, root, cfg["data"]["image_size"], False, cfg["preprocessing"])
    held_data = ImageManifestDataset(held_frame, root, cfg["data"]["image_size"], False, cfg["preprocessing"])

    model = SICERNet(cfg).to(device)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(trainable, lr=cfg["training"]["learning_rate"], weight_decay=cfg["training"]["weight_decay"])
    scheduler = build_scheduler(optimizer, cfg["training"]["warmup_epochs"], cfg["training"]["maximum_epochs"])
    scaler = GradScaler(enabled=cfg["training"]["mixed_precision"])
    group_dro = GroupDRO(cfg["model"]["style_classes"] * 3, cfg["training"]["group_dro_eta"]).to(device)
    selector = CheckpointSelector(cfg["training"]["minimum_auroc_improvement"], cfg["training"]["patience"])
    history = []

    for epoch in range(1, cfg["training"]["maximum_epochs"] + 1):
        losses = train_epoch(model, loader(fit_data, cfg, True), optimizer, scaler, group_dro, cfg, device, epoch)
        stop_records = predict(model, loader(stop_data, cfg), device)
        y = np.array([row["label"] for row in stop_records])
        p = np.array([row["probability"] for row in stop_records])
        auroc = float(roc_auc_score(y, p))
        nll = float(log_loss(y, p, labels=[0, 1]))
        history.append({"epoch": epoch, "early_stop_auroc": auroc, "early_stop_nll": nll, **losses})
        should_stop = selector.update(epoch, auroc, nll, model.state_dict())
        scheduler.step()
        if epoch >= cfg["training"]["warmup_epochs"] and should_stop:
            break

    model.load_state_dict(selector.best[2])
    held_records = predict(model, loader(held_data, cfg), device)
    for row in held_records:
        row.update({"fold": fold, "seed": seed})
        for name, value in zip(("logit_rgb", "logit_hf", "logit_ci"), row.pop("cue_logits")):
            row[name] = value
        for name, value in zip(("rho_rgb", "rho_hf", "rho_ci"), row.pop("reliability")):
            row[name] = value
        for name, value in zip(("route_rgb", "route_hf", "route_ci"), row.pop("routing")):
            row[name] = value

    checkpoint = Path(cfg["project"]["output_root"]) / "checkpoints" / f"seed_{seed}" / f"fold_{fold}.pt"
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"model": model.state_dict(), "seed": seed, "fold": fold, "best_epoch": selector.best[1], "config": cfg}, checkpoint)
    prediction_path = Path(cfg["project"]["output_root"]) / "oof" / f"seed_{seed}_fold_{fold}.csv"
    prediction_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(held_records).to_csv(prediction_path, index=False)
    history_path = Path(cfg["project"]["output_root"]) / "history" / f"seed_{seed}_fold_{fold}.json"
    history_path.parent.mkdir(parents=True, exist_ok=True)
    history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
    return {"seed": seed, "fold": fold, "best_epoch": selector.best[1], "checkpoint": str(checkpoint), "predictions": str(prediction_path)}


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--fold", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--dry-contract-check", action="store_true")
    args = parser.parse_args()
    cfg = load_config(args.config)
    frame = pd.read_csv(cfg["data"]["split_manifest"])
    frame["row_id"] = np.arange(len(frame))
    folds = [args.fold] if args.fold is not None else list(range(cfg["data"]["outer_folds"]))
    seeds = [args.seed] if args.seed is not None else cfg["training"]["seeds"]
    plan = []
    for seed in seeds:
        for fold in folds:
            train = frame[frame.fold != fold].reset_index(drop=True)
            held_out = frame[frame.fold == fold].reset_index(drop=True)
            fit_rows, stop_rows = grouped_early_stop_split(train, cfg["data"]["early_stop_fraction"], seed)
            plan.append({"seed": seed, "fold": fold, "fit": len(fit_rows), "early_stop": len(stop_rows), "held_out": len(held_out)})
    if args.dry_contract_check:
        print(json.dumps(plan, indent=2))
        return
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    summaries = [run_one(frame, fold, seed, cfg, device) for seed in seeds for fold in folds]
    summary_path = Path(cfg["project"]["output_root"]) / "cv_summary.json"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(summaries, indent=2), encoding="utf-8")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
