#!/usr/bin/env python
from argparse import ArgumentParser
import json

from sicer_net.config import load_config
from sicer_net.robustness import PERTURBATION_GRID


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    jobs = [{"family": family, "severity": severity} for family, values in PERTURBATION_GRID.items() for severity in values]
    jobs.extend({"family": "reduced_training_data", "severity": x} for x in [0.75, 0.50, 0.25, 0.10])
    jobs.extend({"family": "cue_failure", "severity": x} for x in ["hf_masked", "ci_masked"])
    print(json.dumps(jobs, indent=2))


if __name__ == "__main__":
    main()
