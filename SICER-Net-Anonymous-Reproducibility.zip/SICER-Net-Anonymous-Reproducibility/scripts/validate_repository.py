#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import ast
import yaml


def main():
    parser = ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root)
    cfg = yaml.safe_load((root / "configs/main.yaml").read_text(encoding="utf-8"))
    assert cfg["data"]["outer_folds"] == 5
    assert cfg["training"]["seeds"] == [17, 29, 43]
    assert cfg["calibration"]["threshold"] == 0.480
    assert cfg["statistics"]["bootstrap_replicates"] == 10000
    python_files = sorted(root.glob("sicer_net/*.py")) + sorted(root.glob("scripts/*.py")) + sorted(root.glob("tests/*.py"))
    for path in python_files:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    assert (root / "reference_records/PROVENANCE.md").exists()
    print(f"validated_python_files={len(python_files)}")
    print("configuration_contract=pass")


if __name__ == "__main__":
    main()
