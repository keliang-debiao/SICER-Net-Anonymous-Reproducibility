#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import pandas as pd

from sicer_net.config import load_config
from sicer_net.data import cross_corpus_overlaps


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--report", default="data/processed/cross_corpus_overlap.csv")
    args = parser.parse_args()
    cfg = load_config(args.config)
    development = pd.read_csv(cfg["data"]["development_manifest"])
    external = pd.read_csv(cfg["data"]["external_manifest"])
    overlaps = cross_corpus_overlaps(development, external, cfg["data"]["phash_distance"])
    report = Path(args.report)
    report.parent.mkdir(parents=True, exist_ok=True)
    overlaps.to_csv(report, index=False)
    print(f"cross_corpus_pairs={len(overlaps)} report={report}")
    if len(overlaps):
        raise SystemExit("Cross-corpus overlap detected; resolve the reported external rows before evaluation")


if __name__ == "__main__":
    main()
