#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import json

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

from sicer_net.calibration import GlobalTemperature, StyleBalancedReliabilityCalibrator
from sicer_net.config import load_config
from sicer_net.data import ImageManifestDataset
from sicer_net.engine import predict
from sicer_net.metrics import binary_metrics
from sicer_net.model import SICERNet


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    frame = pd.read_csv(cfg["data"]["external_manifest"])
    frame["row_id"] = np.arange(len(frame))
    dataset = ImageManifestDataset(frame, cfg["data"]["external_root"], cfg["data"]["image_size"], False, cfg["preprocessing"])
    loader = DataLoader(
        dataset, batch_size=cfg["training"]["batch_size"], shuffle=False,
        num_workers=cfg["training"]["num_workers"], pin_memory=True,
        persistent_workers=cfg["training"]["num_workers"] > 0,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_records, all_metrics = [], []

    for seed in cfg["training"]["seeds"]:
        checkpoint_path = Path(cfg["project"]["output_root"]) / "final_checkpoints" / f"seed_{seed}.pt"
        calibration_root = Path(cfg["project"]["output_root"]) / "calibration"
        model = SICERNet(cfg).to(device)
        model.load_state_dict(torch.load(checkpoint_path, map_location=device)["model"])
        records = predict(model, loader, device)
        logits = torch.tensor([row["logit"] for row in records], dtype=torch.float32)
        reliability = torch.tensor([row["reliability"] for row in records], dtype=torch.float32)
        cue_logits = torch.tensor([row["cue_logits"] for row in records], dtype=torch.float32)
        calibration_method = cfg.get("ablation", {}).get("calibrator", "sbrc")
        if calibration_method == "global_temperature":
            calibrator = GlobalTemperature()
            state = torch.load(calibration_root / f"global_temperature_seed_{seed}.pt", map_location="cpu")
            calibrator.load_state_dict(state["state_dict"])
            probability_calibrated = torch.sigmoid(calibrator(logits)).detach().numpy()
        else:
            calibrator = StyleBalancedReliabilityCalibrator(
                cfg["calibration"]["minimum_temperature"], cfg["calibration"]["maximum_temperature"],
                cfg["calibration"]["hidden_units"],
            )
            state = torch.load(calibration_root / f"sbrc_seed_{seed}.pt", map_location="cpu")
            calibrator.load_state_dict(state["state_dict"])
            probability_calibrated = torch.sigmoid(calibrator(logits, reliability, cue_logits)).detach().numpy()
        for row, probability in zip(records, probability_calibrated):
            row["seed"] = seed
            row["probability_calibrated"] = float(probability)
            row["calibration_method"] = calibration_method
            all_records.append(row)
        metrics = binary_metrics(
            [row["label"] for row in records], probability_calibrated,
            cfg["calibration"]["threshold"], cfg["calibration"]["ece_bins"],
        )
        metrics["seed"] = seed
        all_metrics.append(metrics)

    output_root = Path(cfg["project"]["output_root"])
    pd.DataFrame(all_records).to_json(output_root / "external_predictions.jsonl", orient="records", lines=True)
    metrics_path = output_root / "metrics" / "external_by_seed.json"
    metrics_path.parent.mkdir(parents=True, exist_ok=True)
    metrics_path.write_text(json.dumps(all_metrics, indent=2), encoding="utf-8")
    print(json.dumps(all_metrics, indent=2))


if __name__ == "__main__":
    main()
