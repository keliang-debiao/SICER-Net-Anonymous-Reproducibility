#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path

from sicer_net.config import load_config
from sicer_net.data import audit_manifest


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--dataset", choices=["development", "external"], default="development")
    args = parser.parse_args()
    cfg = load_config(args.config)
    key = args.dataset
    manifest = Path(cfg["data"][f"{key}_manifest"])
    root = Path(cfg["data"][f"{key}_root"])
    audited = audit_manifest(manifest, root, cfg["data"]["phash_distance"])
    audited.to_csv(manifest, index=False)
    print(f"audited={len(audited)} components={audited.duplicate_group.nunique()} path={manifest}")


if __name__ == "__main__":
    main()
