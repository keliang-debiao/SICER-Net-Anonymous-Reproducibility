#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import copy
import json
import subprocess
import sys

import yaml

from sicer_net.config import load_config


DEFAULTS = {
    "high_frequency": True,
    "chromatic": True,
    "routing": "reliability",
    "reliability_target": True,
    "style_adversary": True,
    "cross_style_contrast": True,
    "group_dro": True,
    "calibrator": "sbrc",
}


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--matrix", required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    cfg = load_config(args.config)
    with open(args.matrix, "r", encoding="utf-8") as handle:
        matrix = yaml.safe_load(handle)
    jobs = []
    for name, changes in matrix["variants"].items():
        variant = {**DEFAULTS, **(changes or {})}
        jobs.append({"variant": name, "settings": variant})
    if not args.execute:
        print(json.dumps(jobs, indent=2))
        return

    for job in jobs:
        name = job["variant"]
        variant_cfg = copy.deepcopy(cfg)
        variant_cfg.pop("_config_path", None)
        variant_cfg["ablation"] = job["settings"]
        variant_root = Path(cfg["project"]["output_root"]) / "ablations" / name
        variant_cfg["project"]["output_root"] = str(variant_root)
        config_path = variant_root / "resolved_config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(yaml.safe_dump(variant_cfg, sort_keys=False), encoding="utf-8")
        commands = [
            [sys.executable, "scripts/train_cv.py", "--config", str(config_path)],
            [sys.executable, "scripts/fit_calibrators.py", "--config", str(config_path), "--oof-root", str(variant_root / "oof")],
            [sys.executable, "scripts/train_final.py", "--config", str(config_path), "--cv-summary", str(variant_root / "cv_summary.json")],
            [sys.executable, "scripts/evaluate_external.py", "--config", str(config_path)],
        ]
        for command in commands:
            subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
