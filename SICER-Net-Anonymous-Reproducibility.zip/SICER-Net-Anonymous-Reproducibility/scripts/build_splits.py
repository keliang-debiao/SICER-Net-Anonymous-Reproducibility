#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import pandas as pd

from sicer_net.config import load_config
from sicer_net.data import add_grouped_folds


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    source = Path(cfg["data"]["development_manifest"])
    target = Path(cfg["data"]["split_manifest"])
    frame = pd.read_csv(source)
    split = add_grouped_folds(frame, cfg["data"]["outer_folds"], cfg["data"]["split_seed"])
    target.parent.mkdir(parents=True, exist_ok=True)
    split.to_csv(target, index=False)
    counts = split.groupby(["fold", "label"]).size().unstack(fill_value=0)
    print(counts.to_string())
    print(f"saved={target}")


if __name__ == "__main__":
    main()
