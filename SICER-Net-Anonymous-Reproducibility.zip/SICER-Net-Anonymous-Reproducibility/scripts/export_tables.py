#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import pandas as pd

from sicer_net.config import load_config


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--metrics-root", default="artifacts/metrics")
    parser.add_argument("--output", default="reports/generated")
    args = parser.parse_args()
    load_config(args.config)
    source = Path(args.metrics_root)
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    files = sorted(source.glob("*.csv"))
    for path in files:
        frame = pd.read_csv(path)
        frame.to_csv(target / path.name, index=False, float_format="%.6f")
    print(f"exported={len(files)} target={target}")


if __name__ == "__main__":
    main()
