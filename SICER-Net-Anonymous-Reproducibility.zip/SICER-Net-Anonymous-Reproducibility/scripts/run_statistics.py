#!/usr/bin/env python
from argparse import ArgumentParser
import json
import pandas as pd

from sicer_net.config import load_config
from sicer_net.statistics import paired_hierarchical_bootstrap_auc


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--paired", default="artifacts/paired_predictions.csv")
    args = parser.parse_args()
    cfg = load_config(args.config)
    frame = pd.read_csv(args.paired)
    result = paired_hierarchical_bootstrap_auc(
        frame.label, frame.probability_a, frame.probability_b, frame.duplicate_group,
        replicates=cfg["statistics"]["bootstrap_replicates"],
        random_seed=cfg["statistics"]["random_seed"],
    )
    print(json.dumps({"mean_difference": result[0], "ci95": result[1], "p": result[2]}, indent=2))


if __name__ == "__main__":
    main()
