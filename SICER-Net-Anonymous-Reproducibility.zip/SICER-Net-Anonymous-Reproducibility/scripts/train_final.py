#!/usr/bin/env python
from argparse import ArgumentParser
from pathlib import Path
import json

import numpy as np
import pandas as pd
import torch
from torch.cuda.amp import GradScaler
from torch.utils.data import DataLoader

from sicer_net.config import load_config
from sicer_net.data import ImageManifestDataset
from sicer_net.engine import set_seed, train_epoch
from sicer_net.losses import GroupDRO
from sicer_net.model import SICERNet


def main():
    parser = ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--cv-summary", default="artifacts/cv_summary.json")
    args = parser.parse_args()
    cfg = load_config(args.config)
    summary = json.loads(Path(args.cv_summary).read_text(encoding="utf-8"))
    frame = pd.read_csv(cfg["data"]["split_manifest"])
    frame["row_id"] = np.arange(len(frame))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    output_root = Path(cfg["project"]["output_root"]) / "final_checkpoints"
    output_root.mkdir(parents=True, exist_ok=True)

    for seed in cfg["training"]["seeds"]:
        fold_epochs = [row["best_epoch"] for row in summary if row["seed"] == seed]
        if len(fold_epochs) != cfg["data"]["outer_folds"]:
            raise ValueError(f"Expected five outer-fold epochs for seed {seed}")
        fixed_epochs = int(np.median(fold_epochs))
        set_seed(seed)
        dataset = ImageManifestDataset(
            frame, cfg["data"]["development_root"], cfg["data"]["image_size"], True, cfg["preprocessing"]
        )
        loader = DataLoader(
            dataset, batch_size=cfg["training"]["batch_size"], shuffle=True,
            num_workers=cfg["training"]["num_workers"], pin_memory=True,
            persistent_workers=cfg["training"]["num_workers"] > 0,
        )
        model = SICERNet(cfg).to(device)
        trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
        optimizer = torch.optim.AdamW(trainable, lr=cfg["training"]["learning_rate"], weight_decay=cfg["training"]["weight_decay"])
        def multiplier(epoch):
            warmup = cfg["training"]["warmup_epochs"]
            if epoch < warmup:
                return float(epoch + 1) / max(1, warmup)
            progress = (epoch - warmup) / max(1, fixed_epochs - warmup)
            return 0.5 * (1.0 + np.cos(np.pi * progress))
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier)
        scaler = GradScaler(enabled=cfg["training"]["mixed_precision"])
        group_dro = GroupDRO(cfg["model"]["style_classes"] * 3, cfg["training"]["group_dro_eta"]).to(device)
        history = []
        for epoch in range(1, fixed_epochs + 1):
            history.append({"epoch": epoch, **train_epoch(model, loader, optimizer, scaler, group_dro, cfg, device, epoch)})
            scheduler.step()
        torch.save({"model": model.state_dict(), "seed": seed, "fixed_epochs": fixed_epochs, "config": cfg}, output_root / f"seed_{seed}.pt")
        (output_root / f"seed_{seed}_history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
        print(f"seed={seed} fixed_epochs={fixed_epochs}")


if __name__ == "__main__":
    main()
