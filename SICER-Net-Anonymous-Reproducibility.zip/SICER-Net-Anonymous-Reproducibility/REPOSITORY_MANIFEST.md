# Repository Manifest

| Path | Purpose |
|---|---|
| `configs/main.yaml` | Fixed development, model, training, calibration, and evaluation protocol |
| `configs/ablations.yaml` | Component-wise retraining matrix |
| `data/README.md` | Manifest schema and public dataset placement |
| `sicer_net/data.py` | Audit, duplicate grouping, dataset loading, and grouped split logic |
| `sicer_net/cues.py` | RGB, Haar high-frequency, and chromatic cue construction |
| `sicer_net/model.py` | CLIP adapters, reliability routing, bottleneck heads, and deployed model |
| `sicer_net/losses.py` | Reliability, contrastive, style, load, and group-DRO objectives |
| `sicer_net/calibration.py` | Global temperature and SBRC fitting |
| `sicer_net/metrics.py` | Discrimination, threshold, and calibration metrics |
| `sicer_net/statistics.py` | Fold intervals, paired bootstrap, permutation, Holm, and McNemar procedures |
| `sicer_net/robustness.py` | Prespecified image perturbations |
| `sicer_net/baselines.py` | Protocol-matched baseline model registry |
| `sicer_net/engine.py` | Training, prediction, checkpoint, and result serialization |
| `scripts/` | Command-line entry points for the full study sequence |
| `tests/` | Contract tests for cue dimensions, routing, splitting, calibration, and metrics |
| `reference_records/` | Manuscript-aligned reference outputs with explicit provenance |
